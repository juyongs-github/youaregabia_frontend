const SideNav = () => {
  return (
    <nav className="border border-gray-200 bg-white p-3 text-sm">
      <ul className="space-y-2">
        <li className="font-semibold">전체글보기</li>
        <li className="cursor-pointer text-gray-600 hover:text-black">공지</li>
        <li className="cursor-pointer text-gray-600 hover:text-black">자유</li>
        <li className="cursor-pointer text-gray-600 hover:text-black">질문</li>
      </ul>
    </nav>
  );
};

export default SideNav;
