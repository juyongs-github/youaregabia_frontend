const Header = () => {
  return (
    <header className="border-b bg-white">
      <div className="mx-auto max-w-[1200px] px-4 py-4">
        <h1 className="text-xl font-bold">게시판</h1>
      </div>
    </header>
  );
};

export default Header;
