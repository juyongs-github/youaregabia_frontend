const TopBanner = () => {
  return (
    <div className="bg-black text-sm text-white">
      <div className="mx-auto flex max-w-[1200px] justify-between px-4 py-2">
        <span>🔥 오늘의 Top10</span>
        <span className="text-gray-400">example.com</span>
      </div>
    </div>
  );
};

export default TopBanner;
