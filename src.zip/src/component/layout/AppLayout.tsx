import type { ReactNode } from 'react';
import TopBanner from './TopBanner';
import Header from './Header';
import SideNav from './SideNav';
import FooterSearch from './FooterSearch';
import { Outlet } from 'react-router-dom';

interface Props {
  children: ReactNode;
}

const AppLayout = ({ children }: Props) => {
  return (
    <div className="flex min-h-screen flex-col bg-gray-100">
      {/* 최상단 배너 */}
      <TopBanner />

      {/* 헤더 */}
      <Header />

      {/* 메인 영역 */}
      <div className="flex flex-1 justify-center">
        <div className="flex w-full max-w-[1200px] gap-4 px-2">
          {/* 좌측 네비 */}
          <aside className="w-[200px] shrink-0">
            <SideNav />
          </aside>
          <Outlet />

          {/* 컨텐츠 */}
          <main className="flex-1 border border-gray-200 bg-white">
            {children}
          </main>
        </div>
      </div>

      {/* 하단 검색 */}
      <FooterSearch />
    </div>
  );
};

export default AppLayout;
